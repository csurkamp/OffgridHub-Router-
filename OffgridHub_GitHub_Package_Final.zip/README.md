# OffgridHub Router

Dokumentation, Aufbau und Dateien für dein Offgrid IoT-System.